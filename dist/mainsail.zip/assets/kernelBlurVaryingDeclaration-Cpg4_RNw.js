import{S as r}from"./Viewer-B9X4qiKo.js";const e="kernelBlurVaryingDeclaration",a="varying sampleCoord{X}: vec2f;";r.IncludesShadersStoreWGSL[e]=a;
